package com.he187382.mvc.entity;

public enum Type {
    Robusta, Arabica
}
