package com.he187382.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se1879JvHe187382CmsPeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Se1879JvHe187382CmsPeApplication.class, args);
	}

}
