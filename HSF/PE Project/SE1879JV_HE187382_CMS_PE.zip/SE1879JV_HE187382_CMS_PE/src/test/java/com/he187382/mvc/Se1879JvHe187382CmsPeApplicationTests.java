package com.he187382.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se1879JvHe187382CmsPeApplicationTests {

	@Test
	void contextLoads() {
	}

}
